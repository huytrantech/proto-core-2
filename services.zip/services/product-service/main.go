package main

import (
	"context"
	"errors"
	order_services "github.com/huytrantech/proto-core-2/order_service"
	product_services "github.com/huytrantech/proto-core-2/product_service"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/reflection"
	"log"
	"net"
)

type Server struct {
	product_services.ProductServiceServer
	OrderClient order_services.OrderServiceClient
}

func (s *Server) GetProduct(context.Context, *product_services.GetProductRequest) (*product_services.GetProductResponse, error) {

	return &product_services.GetProductResponse{
		Sku:  "sku_11111",
		Name: "product 1233",
	}, nil
}

func (s *Server) GetProduct2(context.Context, *product_services.GetProductRequest) (*product_services.GetProductResponse, error) {
	orderData, err := s.OrderClient.GetOrder2(context.Background(), &order_services.GetOrderRequest{OrderNumber: "test"})
	if err != nil {
		panic(err)
	}
	if orderData == nil {
		panic(errors.New("Order Nil"))
	}

	return &product_services.GetProductResponse{
		Sku:         "sku_11111",
		Name:        "product 1233",
		OrderNumber: orderData.OrderNumber,
	}, nil
}

var address string = "0.0.0.0:50002"
var addressClient string = "0.0.0.0:50051"

func main() {
	lis, err := net.Listen("tcp", address)

	if err != nil {
		log.Fatalf("Fail with %v\n", err)
	}

	log.Printf("Listening on %v", address)

	s := grpc.NewServer()
	orderClient, cleanUp := InitOrderClient()
	defer cleanUp()
	product_services.RegisterProductServiceServer(s, &Server{OrderClient: orderClient})
	reflection.Register(s)
	if err = s.Serve(lis); err != nil {
		log.Fatalf("Fail with %v", err)
	}
}

func InitOrderClient() (order_services.OrderServiceClient, func()) {
	conn, err := grpc.Dial(addressClient, grpc.WithTransportCredentials(insecure.NewCredentials()))

	if err != nil {
		log.Fatalf("Failed to connect %v", err)
	}

	client := order_services.NewOrderServiceClient(conn)
	//DoGreet(c)
	//doGreetManyTimes(c)
	//doLongGreet(c)
	//doGreetEveryOne(c)
	return client, func() {
		conn.Close()
	}
}
