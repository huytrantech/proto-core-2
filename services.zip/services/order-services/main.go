package main

import (
	"context"
	"errors"
	order_services "github.com/huytrantech/proto-core-2/order_service"
	product_services "github.com/huytrantech/proto-core-2/product_service"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/reflection"
	"log"
	"net"
)

type Server struct {
	order_services.OrderServiceServer
	ProductClient product_services.ProductServiceClient
}

func (s *Server) GetOrder(ctx context.Context, request *order_services.GetOrderRequest) (*order_services.GetOrderResponse, error) {

	productData, err := s.ProductClient.GetProduct(ctx, &product_services.GetProductRequest{Sku: "1"})
	if err != nil {
		panic(err)
	}
	if productData == nil {
		panic(errors.New("Product Nil"))
	}
	return &order_services.GetOrderResponse{
		OrderNumber:   "This is ordernumber",
		TotalOrder:    10000,
		Address:       "This is address",
		ProductDetail: &order_services.ProductDetail{NameProduct: productData.Name},
	}, nil
}

func (s *Server) GetOrder2(ctx context.Context, request *order_services.GetOrderRequest) (*order_services.GetOrderResponse, error) {

	return &order_services.GetOrderResponse{
		OrderNumber: "This is ordernumber",
		TotalOrder:  10000,
		Address:     "This is address",
	}, nil
}

var address string = "0.0.0.0:50051"
var addressClient string = "0.0.0.0:50002"

func main() {

	lis, err := net.Listen("tcp", address)

	if err != nil {
		log.Fatalf("Fail with %v\n", err)
	}

	log.Printf("Listening on %v", address)

	s := grpc.NewServer()

	productClient, cleanUp := InitProductClient()
	defer cleanUp()

	order_services.RegisterOrderServiceServer(s, &Server{
		ProductClient: productClient,
	})
	reflection.Register(s)
	if err = s.Serve(lis); err != nil {
		log.Fatalf("Fail with %v", err)
	}
}

func InitProductClient() (product_services.ProductServiceClient, func()) {
	conn, err := grpc.Dial(addressClient, grpc.WithTransportCredentials(insecure.NewCredentials()))

	if err != nil {
		log.Fatalf("Failed to connect %v", err)
	}

	client := product_services.NewProductServiceClient(conn)
	//DoGreet(c)
	//doGreetManyTimes(c)
	//doLongGreet(c)
	//doGreetEveryOne(c)
	return client, func() {
		conn.Close()
	}
}
